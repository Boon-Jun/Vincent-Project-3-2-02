
	
int initialize_lidar(int argc, const char * argv[]);

void scan_lidar(float *x, float *y, float *angle);

void shutdown_lidar();



