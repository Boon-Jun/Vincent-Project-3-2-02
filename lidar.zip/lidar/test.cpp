#include <stdio.h>
#include <math.h> 
#include "lidar.h"

#define COUNTS_PER_REV 384
#define WHEEL_CIRC 20.42
#define VINCENT_BREADTH 12.5
#define PI 3.141592654
#define VINCENT_LENGTH 16

//float vincentDiagonal = sqrt((VINCENT_LENGTH * VINCENT_LENGTH) + (VINCENT_BREADTH * VINCENT_BREADTH));
float vincentCirc = PI * VINCENT_BREADTH;


//leftticks = (unsigned long) ((angleMoved * vincentCirc * COUNTS_PER_REV) / (360.0 * WHEEL_CIRC)); // converts angle to ticks
/*  angleMoved 	: 	ticks conversion
    90				184
    180				368
    270				552
    360				736
 */

//leftTicks = distMoved/WHEEL_CIRC*COUNTS_PER_REV;
/*  distMoved 	: 	ticks conversion
    10 				188
    30				564
    50				940
    100				1880
 */

float x=0, y=0;
float distMoved =0; //x and y are the coordinates from origin (0,0)
unsigned long leftTicks = 0, rightTicks =0;
float angleMoved = 0; //for angle, take clockwise as +ve
float angle_from_origin = 0;
char dir;

int main(int argc, const char * argv[]) {

    initialize_lidar(argc, argv);

    while(1){
        //scanf("%c %d %d", &dir, &leftTicks, &rightTicks);
        printf("Enter direction followed by ticks: \n");

        printf("distMoved : ticks conversion\n");
          printf("10 			188\n");
          printf("30			564\n");
          printf("50			940\n");
          printf("100			1880\n");

          printf("\n");

          printf("angleMoved : ticks conversion\n");
          printf("90			 184\n");
          printf("180			 368\n");
          printf("270			 552\n");
          printf("360			 736\n");
        scanf("%c %d" , &dir, &leftTicks);
        //scanf("%c %f %f", &dir, &distMoved, &angleMoved);
        if (dir=='F') {
            //leftTicks = distMoved/WHEEL_CIRC*COUNTS_PER_REV;

            //use this
            distMoved = leftTicks/COUNTS_PER_REV*WHEEL_CIRC; // converts ticks to distance 
            float rad = angle_from_origin/180.0*PI;
            
            x = distMoved*sin(rad);
            y = distMoved*cos(rad);
            //printf("test %f %f\n", x, y);
            scan_lidar(&x, &y, &angle_from_origin);
        }
        else if (dir == 'B') {
            distMoved = leftTicks/COUNTS_PER_REV*WHEEL_CIRC; // converts ticks to distance
            float rad = angle_from_origin/180.0*PI;

            x = -distMoved*sin(rad);
            y = -distMoved*cos(rad);
            scan_lidar(&x, &y, &angle_from_origin);
        }
        else if (dir == 'L') {
            //leftTicks = (unsigned long) ((angleMoved * vincentCirc * COUNTS_PER_REV) / (360.0 * WHEEL_CIRC)); // converts angle to ticks

            //use this
            angleMoved = (float) (leftTicks / (vincentCirc * COUNTS_PER_REV)) * (360.0 * WHEEL_CIRC);// converts ticks to angle
            angle_from_origin -= angleMoved;
            scan_lidar(&x, &y, &angle_from_origin);
        }
        else if (dir == 'R') {
            //leftTicks = (unsigned long) ((angleMoved * vincentCirc * COUNTS_PER_REV) / (360.0 * WHEEL_CIRC)); // converts angle to ticks

            //use this
            angleMoved =  (float) (leftTicks / (vincentCirc * COUNTS_PER_REV)) * (360.0 * WHEEL_CIRC); //converts ticks to angle
            angle_from_origin += angleMoved;
            scan_lidar(&x, &y, &angle_from_origin);
        }
    }

    shutdown_lidar();

    return 0;
}
